/**
 * 
 */
/**
 * @author PrafullaKumarTripath
 *
 */
package com.ibm.eis.bean;
public class ProductDetails {
	String Product_Name;
	String Product_Description;
	String Product_Category;
	int Product_Price;
	int Product_Id;
	public ProductDetails(String Product_Name, String Product_Description, Integer Product_Id, String Product_Category, Integer Product_Price ) {
		this.Product_Name = Product_Name;
		this.Product_Description = Product_Description;
		this.Product_Id = Product_Id;
		this.Product_Category = Product_Category;
		this.Product_Price = Product_Price;
	}
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	public String getProduct_Description() {
		return Product_Description;
	}
	public void setProduct_Description(String product_Description) {
		Product_Description = product_Description;
	}
	public String getProduct_Category() {
		return Product_Category;
	}
	public void setProduct_Category(String product_Category) {
		Product_Category = product_Category;
	}
	public int getProduct_Price() {
		return Product_Price;
	}
	public void setProduct_Price(int product_Price) {
		Product_Price = product_Price;
	}
	public int getProduct_Id() {
		return Product_Id;
	}
	public void setProduct_Id(int product_Id) {
		Product_Id = product_Id;
	}
}


