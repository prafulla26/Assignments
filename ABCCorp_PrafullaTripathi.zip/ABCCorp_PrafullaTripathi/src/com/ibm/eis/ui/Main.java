/**
 * 
 */
/**
 * @author PrafullaKumarTripath
 *
 */
package com.ibm.eis.ui;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.ibm.eis.bean.ProductDetails;



public class Main {
	
	
	public static void main(String[] args) throws SQLException {
			ServiceInterface service = new ServiceClass();
			Scanner sc =new Scanner(System.in);
			int accountno = 0;
			int amount =0;
			while(true) {
			System.out.println("Welcome to App");
			System.out.println("Enter 1. Generate Bill by entering Product code and quantity   \n Enter 2. Exit");
			int choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1 :Integer Product_Id = 0;
					System.out.println("Enter Product_Id");
					Integer Product_Id1 = sc.nextInt();
					while(true) {
					System.out.println("Enter Product_id (must contain digit,length must be 4 digit");
					Product_Id1 = sc.nextInt();
					
					}
					
	}
     }
	  }
       }
			
			
			
			
			