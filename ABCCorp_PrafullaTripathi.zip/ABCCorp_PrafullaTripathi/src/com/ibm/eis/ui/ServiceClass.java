package com.ibm.eis.ui;

public class ServiceClass implements ServiceInterface {

	@Override
	public boolean validateProduct_Id(Integer product_Id1) {
		// TODO Auto-generated method stub
		return false;
	}

}
