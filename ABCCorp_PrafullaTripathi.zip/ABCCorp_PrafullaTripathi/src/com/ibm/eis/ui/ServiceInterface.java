package com.ibm.eis.ui;

public interface ServiceInterface {

	boolean validateProduct_Id11(Integer product_Id1);

	boolean validateProduct_Id1(Integer product_Id1);

	boolean validateProduct_Id(Integer product_Id);

}
