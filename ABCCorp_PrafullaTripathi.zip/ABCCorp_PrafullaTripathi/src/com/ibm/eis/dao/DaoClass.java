/**
 * 
 */
/**
 * @author PrafullaKumarTripath
 *
 */
package com.ibm.eis.dao;


import com.ibm.eis.bean.ProductDetails;


interface IProductDAO{
	ProductDetails getProductDetails (int Product_Id);
	} 
class ProductDAO implements IProductDAO{ 
	public ProductDetails getProductDetails (int Product_Id){
		return null; } } 