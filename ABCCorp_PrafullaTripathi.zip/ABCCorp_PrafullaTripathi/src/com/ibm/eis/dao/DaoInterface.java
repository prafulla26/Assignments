package com.ibm.eis.dao;

import com.ibm.eis.bean.ProductDetails;

public interface DaoInterface {

	void storeIntoMap1(ProductDetails ProductDetails);

	void storeIntoMap(ProductDetails productDetails);

}
